﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PlayerEntitiesLib
{
    public class PlayerCard
    {
        public long Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string Cote { get; set; } //varie de H1 a H12 pour hommes et de W1 a W12 pour femmes
        public string Team { get; set; }
        public int PartieJoue { get; set; }
        public int Goals { get; set; }
        public int Assists { get; set; }
        public int Points { get; set; }



        public void PrintPlayerCard()
        {
            Console.WriteLine("Id :" + this.Id);
            Console.WriteLine("First Name :" + this.FirstName);
            Console.WriteLine("Last Name :" + this.LastName);
            Console.WriteLine("Age :" + this.Age);
            Console.WriteLine("Cote :" + this.Cote);
            Console.WriteLine("Team Name :" + this.Team);
            Console.WriteLine("PJ : " + this.PartieJoue);
            Console.WriteLine("G : " + this.Goals);
            Console.WriteLine("A : " + this.Assists);
            Console.WriteLine("Pts : " + this.Points);
            Console.WriteLine("------------------------------------------");
        }

    }
}
