﻿using PLayerDALLib;
using PlayerEntitiesLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PlayerBLLLib
{
    public class PlayerManager
    {
        public static List<PlayerCard> SearchForName(string strToSearch)
        {

            {
                return PlayerService.SearchForName(strToSearch);
            }


        }
    }
}