﻿using PlayerEntitiesLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PLayerDALLib
{
    public class PlayerService
    {
        public static List<PlayerCard> SearchForName(string strToSearch)
        {
            List<PlayerCard> lst = null;
            //db search...
            return lst;
        }

    }
}